#include<stdio.h>
#include<cs50.h>
void convert();
int main()
{
        int i,k;
         string a;
         char init[10];
         a = GetString();            /* taking input*/
         init[0] = a[0];
         for(i=1, k=1;a[i]!='\0';i++)   /*taking the initials*/
         {  
            if(a[i]==' ')
            {   
                init[k] = a[i+1];
                k++;
              }
         
         }
        init[k] = '\0';
        convert(init,k);     /*function to convert lowwercase to uppercase*/
        printf("%s\n",init);
        
        }
        
  void convert( string f,int x)   /*begining of the function*/
  {
    int i;
    
    for(i=0;i<=x;i++)
    {
        if(f[i] >= 'a')
        { f[i] = f[i] - 32;
        }
    }
    }
    