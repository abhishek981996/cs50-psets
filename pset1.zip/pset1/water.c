#include<stdio.h>
#include<cs50.h>
int main()
{
    int min;
    printf("enter the no of minutes:");
    min = GetInt();
    printf("minutes: %i\nbottles:%i\n",min,min*12);
    return 0;
   
    }
    