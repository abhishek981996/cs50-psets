#include<stdio.h>
#include<cs50.h>
int getposint();
int main()
{   
    int a,pos,row,space,obj;
    printf("Height:");
    a = GetInt();
    pos = getposint(a);
    
    for(row = 1;row <= pos;row++)    /*loop starts here*/
    {   
        for(space = pos;space > row;space--)
        printf(" ");
        
        for(obj = 0;obj < row+1;obj++)
        printf("#");
        printf("\n");
    }
  }
    /*function for positive int starts here*/
    int getposint(int c)
    {
        
        while(c <1 || c>25)
        {
                printf("Height:");
                c = GetInt();
               
                }
        
    return c; 
    }
    