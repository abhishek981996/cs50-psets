#include<stdio.h>
#include<cs50.h>
#include<math.h>
float GetposFloat(float);
int highestcnt(int);
int main()
{
    float input,check;
    int round,value;
    printf("O Hail!How much change is owed?\n");
    input = GetFloat();
    check = GetposFloat(input);  /*checking for positive value and returning positive no*/
    /*rounding up the float value*/
    round = roundf(check*100);
   value = highestcnt(round);
   printf("%i",value);
    }
    /* check for positive vallue */
    
    float GetposFloat(float x)
        {
            while(x<0)
            {   
                 printf("How much change is owed?\n");
                x = GetFloat();
             }
          return x;
        }
    int highestcnt(int a)
     {
        int i=0,j=0,k=0,l=0;
            while(a!=0)
                {
                     if(a>=25)
                      { i = a/25;
                        a = a%25;
                        }
                       
                    else if(a>=10)
                      { j = a/10;
                        a = a%10;
                        }
                       
                     else if(a>=5)
                      { k = a/5;
                        a = a%5;
                        }
                     else
                      { l = a/1;
                        a = a%1;
                        }
                   }
                   return (i+j+k+l);
               }
                        
                        
                              
    
    
    
    
   