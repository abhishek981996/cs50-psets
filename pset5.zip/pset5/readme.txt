Spell-checker

Implemented a dictionary using a hash table. Wrote an
efficient hash function and optimized the Code’s running 
time.
